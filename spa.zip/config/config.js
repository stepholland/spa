// module.exports = {
//   PORT: 5000,
//   databaseUser: "root",
//   databasePassword: "root",
//   databaseHost: "localhost",
//   database: "primespa",
//   secret: "eilfjdsi901i43rdsvlksafakf",
//   tokenLifetime: 1000 * 60 * 60 * 24,
//   saltRounds: 10,
// };

module.exports = {
  PORT: 5000,
  databaseUser: "b9192a2fa721cf",
  databasePassword: "8563ac2a",
  databaseHost: "us-cdbr-east-02.cleardb.com",
  database: "heroku_b78dd6f17fa80c8",
  secret: "eilfjdsi901i43rdsvlksafakf",
  tokenLifetime: 1000 * 60 * 60 * 24,
  saltRounds: 10,
};
