const data = {
  phone: "918.710.2060",
  fax: "918.392.4552",
  email: "info@primemedspa.com",
  name: "Prime Medical spa",
  address1: "7307 S Yale Ave Tulsa",
  address2: "OK 74136",
  copyright: "Copyright 2020 Prime Medical Spa, Tulsa, OK",
};

export default data;
