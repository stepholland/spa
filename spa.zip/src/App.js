import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import { Home } from "./pages/Home";

import { About } from "./pages/About";
import { EventsPromotion } from "./pages/EventsPromotion";
import { PrimeMedical } from "./pages/PrimeMedical";
import { PrimeMen } from "./pages/PrimeMen";
import { PrimeSpa } from "./pages/PrimeSpa";
import { Products } from "./pages/Products";

function App() {
  return (
    <div className="App">
      <BrowserRouter basename={process.env.PUBLIC_URL}>
        <Switch>
          <Route path="/" component={Home} exact />

          <Route path="/about" component={About} exact />
          <Route path="/eventsandpromo" component={EventsPromotion} exact />
          <Route path="/primemed" component={PrimeMedical} exact />
          <Route path="/primemen" component={PrimeMen} exact />
          <Route path="/primespa" component={PrimeSpa} exact />
          <Route path="/products" component={Products} exact />
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
