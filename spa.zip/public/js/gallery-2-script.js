
$(function() {
	'use strict';

/*--------------------------------------------------------------
    Gallery Lightbox pluging
--------------------------------------------------------------*/
    $('.gallery-2 .thumbnail a').nivoLightbox({
         effect: 'fall'
    });

}); // end of document.ready