import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Home from "./pages/Home";

import About from "./pages/About";
import EventsPromotion from "./pages/EventsPromotion";
import Services from "./pages/Services";
import PrimeMen from "./pages/PrimeMen";
import PrimeSpa from "./pages/PrimeSpa";
import Products from "./pages/Products";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";

function App() {
  return (
    <div className="App">
      <BrowserRouter basename={process.env.PUBLIC_URL}>
        <Switch>
          <Route path="/" component={Home} exact />
          <Route path="/about" component={About} exact />
          <Route path="/eventsandpromo" component={EventsPromotion} exact />
          <Route path="/services" component={Services} exact />
          <Route path="/primemen" component={PrimeMen} exact />
          {/* <Route path="/primespa" component={PrimeSpa} exact /> */}
          <Route path="/products" component={Products} exact />
          <Route path="/login" component={Login} exact />
          <Route path="/dashboard" component={Dashboard} exact />
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
