const data = {
  phone: "123412",
  fax: "111232341",
  email: "info@SPA.com",
  name: "SPA",
  address1: "1232 Tulsa",
  address2: "OK 23234",
  copyright: "Copyright 2020 Spa, Tulsa, OK",
};

export default data;
