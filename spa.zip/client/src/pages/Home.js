import React, { Component } from "react";
import ServicesItem from "../components/ServicesItem";
import Footer from "../components/Footer";
import DarkNav from "../components/DarkNav";
import Constants from "../Constants";

export class Home extends Component {
  componentDidMount() {
    window.executeHome();
    window.scrollTo(0, 0);
  }

  render() {
    return (
      <div id="home-1">
        <DarkNav />

        <div className="hero row" id="main-hero">
          <div class="title home-title">
            <div>
              <h3>Make an Appointment</h3>
              <p>
                <i className="fa fa-phone phoneicon"></i>
                {Constants.phone}
              </p>
              <p>Office open M-F / 9 am - 5 pm</p>
            </div>
          </div>
          <div className="hero-slider">
            <div className="row item item-1">
              <div className="overlay" />
            </div>
            <div className="row item item-2">
              <div className="overlay" />
            </div>
          </div>
          <div className="clearfix" />
          <a
            href="#"
            class="btn btn-default"
            style={{ opacity: 0, cursor: "default" }}
            onClick={(e) => e.preventDefault()}
          >
            Explore Victoria
          </a>
        </div>

        <div className="about-resort">
          <div className="row">
            <section className="about col col-sm-6">
              <h2 className="hidden">About</h2>
              <div className="about-slider">
                <div>
                  <div className="col col-sm-8 col-sm-offset-2 col-lg-8 col-lg-offset-2 section-title">
                    <h3>We are Prime Spa</h3>
                    <p>
                      The place for clients who desire non-surgical beauty
                      solutions. Your face is our specialty. It’s our mission is
                      to help you feel confident in your skin every day by
                      combining the art and science of beauty to help you
                      achieve the look you desire.  We provide top-of-the-line,
                      physician-directed services and medical grade skin care
                      products.   The services we provide use the latest
                      technology, are non-invasive, and in most cases, you are
                      able to return to work on the same day.   It’s not vain to
                      want to look your best.  It means you are striving to be
                      your very best, and we want to help you look as great as
                      you feel.
                    </p>
                  </div>
                  <img
                    src="images/about/slider/slider-1.jpg"
                    alt="Slide Picture"
                    className="img img-responsive"
                  />
                </div>
              </div>
            </section>

            <section className="resort col col-sm-6">
              <div className="resort-slider">
                <div className="item item-1">
                  <div className="overlay" />
                </div>
              </div>
              <div className="title">
                <h2>Prime Spa</h2>
              </div>
            </section>
          </div>
        </div>

        {/* <section className="services">
          <h2 className="hidden">Service</h2>
          <div className="container">
            <div className="top-button row">
              <div className="col pull-left">
                <p>Prime Spa services</p>
              </div>
              <div className="col col-sm-9" />
            </div>

            <ServicesItem
              heading_hidden={"HydraFacials"}
              heading={"HydraFacials"}
              subtitle={"Cleanse + Peel, Extract + Hydrate, Fuse + Protect."}
              align1={"left"}
              align2={"right"}
              image_class={"hydrafacial"}
            />
            <ServicesItem
              heading_hidden={"PRIME ACNE TREATMENTS"}
              heading={"PRIME ACNE TREATMENTS"}
              subtitle={
                "ACNE PROBLEMS CAN REALLY AFFECT YOUR APPEARANCE AND SELF-CONFIDENCE."
              }
              align1={"right"}
              align2={"left"}
              image_class={"acne"}
            />
            <ServicesItem
              heading_hidden={"BOTOX"}
              heading={"BOTOX"}
              subtitle={
                "TO RELAX THE SKIN AND RESTORE ITS YOUTHFUL APPEARANCE."
              }
              align1={"left"}
              align2={"right"}
              image_class={"botox"}
            />
          </div>
        </section> */}

        <Footer />
      </div>
    );
  }
}

export default Home;
