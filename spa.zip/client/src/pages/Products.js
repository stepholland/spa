import React, { Component } from "react";
import DarkNav from "../components/DarkNav";
import Footer from "../components/Footer";

export class Products extends Component {
  componentDidMount() {
    window.executeHome();
    window.scrollTo(0, 0);
  }
  render() {
    return (
      <div id="about">
        <DarkNav />

        <div className="banar">
          <div className="container">
            <div className="row">
              <div className="col col-sm-6" />
              <div className="col col-sm-6">
                <span
                  className="playfair"
                  style={{ opacity: 0, cursor: "default" }}
                >
                  Spa &amp; Wellness
                </span>{" "}
                <h2>Products</h2>
              </div>
            </div>
          </div>
        </div>
        <div className="product-bg">
          <div className="page-breadcrumb simple-page-breadcrumb">
            <div className="container">
              <div className="row">
                <div className="col">
                  <ol className="playfair breadcrumb">
                    <li>
                      <a href="#">Prime Spa</a>
                    </li>
                    <li className="active">Products</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <section className="about-victoria">
            <div className="container">
              <div className="row section-title">
                <div className="col col-md-10 col-md-offset-1">
                  <p>
                    Products we feature at Prime are custom made just for your
                    skin needs. We carry multiple lines to cater to every
                    concern and skin condition you may have. Product lines we
                    carry include: Prime Custom Skincare, Obagi, Revision, Elta
                    MD (ONLY Elite Account in Oklahoma) , Latisse.
                  </p>
                </div>
              </div>
            </div>
          </section>
        </div>

        <Footer />
      </div>
    );
  }
}

export default Products;
