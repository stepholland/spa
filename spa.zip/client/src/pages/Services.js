import React, { Component } from "react";
import DarkNav from "../components/DarkNav";
import GridItem from "../components/GridItem";
import Footer from "../components/Footer";

export class Services extends Component {
  componentDidMount() {
    window.executeHome();

    window.scrollTo(0, 0);
  }
  render() {
    return (
      <div id="shop">
        <DarkNav />

        <section className="shop-title ">
          <div className="container">
            <div className="row section-title">
              <h2>SERVICES</h2>
              <p className="sub-para">
                We all desire clear, radiant skin. With numerous treatment
                options and a multitude of products available in the market, you
                are maybe left asking “What’s best for me?”   To help ease the
                confusion, we offer complimentary consultations to educate you
                about what’s going on with your skin and how we can best work to
                achieve your desired results.  Services include injectables,
                skin resurfacing, micro-needling, laser hair removal, acne
                treatments, and much more.
              </p>
            </div>
          </div>
        </section>
        <section className="shop primemedcontainer">
          <h2 className="hidden">Shop</h2>
          <div className="container">
            <div className="content row">
              <GridItem
                title={"Sciton NanoPeel"}
                subinfo={
                  "recommended to treat fine lines, pores, and overall texture. This very light resurfacing offers no downtime or discomfort with immediate results. The procedure can be performed on a Friday and you can return to makeup and normal routine the following Monday."
                }
                price={false}
              />
              <GridItem
                title={"Sciton MICROLASERPEEL"}
                subinfo={
                  "A microlaserPeel removes the very outer layer of the skin to improve fine lines, pigmentation, tone, and texture- restoring a more youthful appearance. In contrast to our NanoPeel, this peel requires downtime and no makeup for 4-7 days."
                }
                price={false}
              />
              <GridItem
                title={"Sciton Deep Resurfacing"}
                subinfo={
                  "Resurfacing with Contour TRL is a deep laser peel that safely removes deep wrinkles, especially those around lips and eyes. No other non-surgical technology can turn back time as effectively as Contour TRL."
                }
                price={false}
              />
            </div>
            <div className="content row">
              <GridItem
                title={"Sciton ProFractional Therapy"}
                subinfo={
                  "Profractional Therapy treats a fraction of the skin, stimulating new collagen growth and improving your skins tone, texture, fine lines, and acne scars. This treatment gives great results with minimal downtime."
                }
                price={false}
              />
              <GridItem
                title={"Sciton Forever Young BBL – Photofacial"}
                subinfo={
                  "Finally a treatment that can actually slow down the signs of aging and keep you forever young.   Forever Young BBL patients see improvement in full-face rejuvenation, skin texture and skin discolorations. Scientific evidence demonstrates regular maintenance treatments using Forever Young BBL rejuvenates skin and delays skin aging by restoring the gene expression pattern of aged human skin to resemble young skin."
                }
                price={false}
              />
              <GridItem
                title={"Prime Acne Treatments"}
                subinfo={
                  "Acne problems can really affect your appearance and self-confidence.  Prime is directed by a board certified immunologist and allergist with a fellowship in dermatology who combines the latest in lasers, peels, and medical grade products to clear up acne and erase any scarring left behind. Your treatment provider will customize a treatment plan that will deliver the results you are looking for"
                }
                price={false}
              />
            </div>
            <div className="content row">
              <GridItem
                title={"BBL Laser Hair Removal"}
                subinfo={
                  "At Prime we have the best and latest, pain-free laser hair removal system. Introducing BBL Laser Hair Removal to help you achieve permanent hair reduction. Depending on the treatment area, a session of laser hair removal can be as little as a few minutes or up to an hour of treatment. After each session, the hair in the treated area will appear finer and lighter."
                }
                price={false}
              />
              <GridItem
                title={"Microneedling"}
                subinfo={
                  "Micro-needling is an advanced, non-surgical procedure that can revitalize your skin from the effects of time. By using a handpiece with several very fine needles at the tip, this gentle treatment can correct the appearance of wrinkles, scarring, acne scars, and pigmentation among other skin inconsistencies. A member of our highly trained medical team will carefully maneuver this handpiece over the surface of the skin. As the micro-needles make contact, they will create tiny microchannels that help influence your body’s production of collagen and elastin, which are two key proteins that help keep our skin looking youthful and healthy. Once the production of these two proteins have begun, patients can feel the difference of silkier skin."
                }
                price={false}
              />
              <GridItem
                title={"Platelet-rich Plasma (PRP)"}
                subinfo={
                  "Platelet-rich Plasma (PRP) is a substance derived from your own blood that can be used to trigger a healing response. Platelets contain several growth factors that attract stem cells and increase rebuilding of tissues over several months. PRP has recently become popular for healing sports injuries and for cosmetic procedures to increase collagen and improve overall skin health. Schedule a complimentary consultation for pricing"
                }
                price={false}
              />
            </div>
            <div className="content row">
              <GridItem
                title={"The Orgasm Shot"}
                subinfo={
                  "The Orgasm Shot- also known as the O-Shot®, is a non-surgical, completely safe platelet-rich plasma technique to restore sexual health and urinary continence in women. Platelet Rich Plasma is obtained from your own blood and applied to the clitoris and vagina to stimulate multi-potent stem cells. This generates healthier tissue in the areas of sexual response and urinary continence, leading to improved health of the lubricating Skene’s Glands, urethra, and vaginal wall."
                }
                price={false}
              />
              <GridItem
                title={"Kybella"}
                subinfo={
                  "Kybella is the first and only FDA-approved, nonsurgical treatment that contours and improves the appearance of submental fullness (double chin). When injected into the fat beneath your chin, Kybella® causes the destruction of fat cells. Once destroyed, those cells cannot store or accumulate fat. Treatment is typically required 2-4 times in 7-10 week intervals, and the results are permanent.Schedule a complimentary consultation for pricing"
                }
                price={false}
              />
              <GridItem
                title={"Ozone Therapy"}
                subinfo={
                  "Ozone Therapy has been utilized and extensively studied for many decades. Ozone inactivates bacteria, viruses, fungi, yeast and protozoa. Ozone stimulates oxygen metabolism and activates the immune system. Ozone is utilized in our office to treat the following (*Individual results vary and are not guaranteed)"
                }
                price={false}
              />
            </div>
            <div className="content row">
              <GridItem
                title={"Botox"}
                subinfo={
                  "Forehead wrinkles, crow’s feet and frown lines are no challenge for Botox Cosmetic. This treatment targets one of the most common underlying causes of wrinkles; repeated muscle contractions. When injected into the site of wrinkles and fine lines, BOTOX® Cosmetic temporarily relaxes the muscles there, smoothing and softening the skin above them. Most injection sessions take about 15 minutes to complete, and clients will typically see the results gradually kick in throughout the week. The full effects of Botox® take about 10 – 14 days. Results last anywhere from 3-6 months depending on the individual."
                }
                price={false}
              />
              <GridItem
                title={"Dermal Filler"}
                subinfo={
                  "Dermal Fillers are used in areas that have undergone volume loss such as the lips, cheeks, smile lines, and jaw line. These products are hyaluronic acid based which attracts water in the body to plump and fill these areas. As we age, our collagen levels decrease drastically, and dermal fillers provide a way to restore those youthful levels of collagen – turning back the hands of time. These products can last anywhere from a few months to a few years. At Prime Med Spa, we desire to help you achieve the exact result you want whether it’s subtle volume, or dramatic plumping. Upon evaluation, we will determine a treatment plan to give you optimum results."
                }
                price={false}
              />
              <GridItem
                title={"HYDRAFACIALS"}
                subinfo={
                  "THE AWARD-WINNING HYDRAFACIAL® ADVANCES SKIN HEALTH BY MERGING INVIGORATING SPA THERAPIES WITH ADVANCED MEDICAL TECHNOLOGY. THIS FACIAL TAKES NON-INVASIVE SKIN REJUVENATION TO A WHOLE NEW LEVEL. IN CLINICAL STUDIES PERFORMED BY LEADING U.S. DOCTORS, THE HYDRAFACIAL® WAS SHOWN TO PROVIDE BETTER RESULTS THAN MANY OTHER SKIN REJUVENATION DEVICES, AND IS THE ONLY HYDRADERMABRASION TREATMENT THAT USES THE PATENTED 4-IN-1 VORTEX TECHNOLOGY™. THE HYDRAFACIAL MD® PROPRIETARY SKIN SOLUTIONS ARE CLINICALLY FORMULATED USING ADVANCED INGREDIENTS TO TARGET SPECIFIC SKIN CONCERNS INCLUDING UNEVEN TONE AND TEXTURE, FINE LINES AND WRINKLES, BLEMISHES, AND DEHYDRATED SKIN."
                }
                price={false}
              />
            </div>
            <div className="content row">
              <GridItem
                title={"DERMAPLANE"}
                subinfo={
                  "DERMAPLANING IS A SIMPLE AND SAFE PROCEDURE FOR EXFOLIATING THE EPIDERMIS AND RIDDING THE SKIN OF FINE VELLUS HAIR OR PEACH FUZZ. THERE IS NO DOWNTIME AND GIVES YOU IMMEDIATE RESULTS. $35 PER FACIAL."
                }
                price={false}
              />
              <GridItem
                title={"WAXING"}
                subinfo={
                  "WAXING PROVIDES SMOOTH, SILKY, HAIR-FREE SKIN FOR A LONGER PERIOD OF TIME THAN SHAVING. WAXING ALSO DOES NOT CAUSE STUBBLE ASSOCIATED WITH SHAVING. THIS SYSTEM IS SELF-PRESERVING ANTI-BACTERIAL/ANTI-MICROBIAL SO IT’S SAFE, CLEAN AND GERM FREE. THE NEXT TIME YOU NEED A BROW OR LIP WAX, GIVE THIS A TRY. BROW WAX – $15 LIP WAX – $12"
                }
                price={false}
              />
              <GridItem
                title={"MASSAGE THERAPY"}
                subinfo={
                  "Experience total relaxation or benefit from therapeutic bodywork for pain management.  Depending on your needs, hot stone treatment, acupuncture, acupressure, or Chinese cupping are additional treatments you can add to get the most of your session.  Massage times range from 30 minutes to 2 hours.Contact Connie Worden, LMT at 918-850-4286"
                }
                price={false}
              />
            </div>
            <div className="content row">
              <GridItem
                title={"REDKEN SALON"}
                subinfo={
                  "Prime Medical Spa is home to Redken certified hair colorist and design stylist, Sarah Dean. She carries an extensive line of Redken and Pureology haircare products.  With her extensive knowledge in Redken and Pureology haircare she can provide you with a perfectly personalized regimen."
                }
                price={false}
              />
              <GridItem
                title={"HAIR LOSS RESTORATION"}
                subinfo={
                  "WHERE SCIENCE, TECHNOLOGY & RESULTS MEET. Hair loss restoration services at Prime are provided by Hair Loss Restoration Co. OUR VISION To be an information source and provide services for clients experiencing hair loss, helping them obtain the best decision regarding their goals and expectations for hair health and regrowth. SERVICES Initial comprehensive analysis. Hair wear for those who want an instant solution for thinning hair. Laser hair therapy. The best products on the market for your hair loss needs; compounding prescriptions available. Plasma rich platelet (PRP) therapy. On-Site immunologist, dermatologist, allergist, IV nutrition therapy. Follow-up analysis and scope. For appointments and pricing, contact Kellie August phone- 918-605-5377 www.hairlossrestorationco.com"
                }
                price={false}
              />
              <GridItem
                title={"PERMANENT COSMETICS"}
                subinfo={
                  "Permanent Cosmetics can enhance your brows, eyes and lips with results that last! Save time on your daily beauty routine and look your best morning, noon and night. It is especially beneficial for people who can’t wear cosmetics due to allergies and sensitive skin, active people who don’t want to worry about sweating off and reapplying cosmetics, and those who are visually impaired and have difficulty applying cosmetics. 3D Aereola Pigmentation: *COMING SOON* Women who have undergone mastectomies, other breast surgery or are simply not happy with their areola may elect to have permanent re-pigmentation of the breast. Techniques such as permanent areola re-pigmentation and nipple restoration employs cosmetically tattooed micro pigmentation as a way to restore the natural beauty of your breasts. Schedule a complimentary consultation for pricing with either Karen Barnett or Tammy Mathias. Karen Barnett, RDH, CMM Microblading & Permanent Makeup Artist Cell: 918-230-8862 Facebook link: /skindeepabrowstul Instagram link: /skindeepabrowstul www.skindeepbrows.com Tammy Mathias, RDH, CMM Permanent Cosmetic Artist Cell: 918-606-3664"
                }
                price={false}
              />
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }
}

export default Services;
