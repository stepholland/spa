import React, { Component } from "react";

class Dashboard extends Component {
  componentDidMount() {
    const token = sessionStorage.getItem("jwt");
    if (!token) {
      this.props.history.push("/login");
    }
  }

  render() {
    return <div></div>;
  }
}

export default Dashboard;
