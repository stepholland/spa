import React, { Component } from "react";
import { Link } from "react-router-dom";
import Footer from "../components/Footer";
import DarkNav from "../components/DarkNav";
export class About extends Component {
  componentDidMount() {
    window.executeHome();
    window.scrollTo(0, 0);
  }

  render() {
    return (
      <div id="about">
        <DarkNav />

        <div className="banar">
          <div className="container">
            <div className="row">
              <div className="col col-sm-6" />
              <div className="col col-sm-6">
                <span
                  className="playfair"
                  style={{ opacity: 0, cursor: "default" }}
                >
                  Spa &amp; Wellness
                </span>
                <h2>About Prime Spa</h2>
              </div>
            </div>
          </div>
        </div>

        <div className="page-breadcrumb simple-page-breadcrumb">
          <div className="container">
            <div className="row">
              <div className="col">
                <ol className="playfair breadcrumb">
                  <li>
                    <a href="#">Home</a>
                  </li>
                  <li className="active">About us</li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        <section className="about-victoria">
          <div className="container">
            <div className="row section-title">
              <div className="col col-md-10 col-md-offset-1">
                <h2>Welcome to Medical Spa</h2>
                <p>
                  The place for clients who desire non-surgical beauty
                  solutions. Your face is our specialty. It’s our mission is to
                  help you feel confident in your skin every day by combining
                  the art and science of beauty to help you achieve the look you
                  desire.  We provide top-of-the-line, physician-directed
                  services and medical grade skin care products.   The services
                  we provide use the latest technology, are non-invasive, and in
                  most cases, you are able to return to work on the same day.  
                  It’s not vain to want to look your best.  It means you are
                  striving to be your very best, and we want to help you look as
                  great as you feel.
                </p>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    );
  }
}

export default About;
