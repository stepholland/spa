import React, { Component } from "react";
import DarkNav from "../components/DarkNav";
import Footer from "../components/Footer";
import EventsPromoItem from "../components/EventsPromoItem";

export class EventsPromotion extends Component {
  componentDidMount() {
    window.executeHome();

    window.scrollTo(0, 0);
  }
  render() {
    return (
      <div id="home-1" className="eventspromo">
        <DarkNav />
        <div className="services">
          <div className="container">
            <div className="facial">
              <EventsPromoItem
                name={"Massage Therapy"}
                info={
                  "Experience total relaxation or benefit from therapeutic bodywork for pain management.  Depending on your needs, hot stone treatment, acupuncture, acupressure, or Chinese cupping are additional treatments you can add to get the most of your session.  Massage times range from 30 minutes to 2 hours."
                }
                contact={"Contact Connie Worden, LMT at 918-850-4286"}
              />
              <EventsPromoItem
                name={"Redken Salon"}
                info={
                  "Prime Medical Spa is home to Redken certified hair colorist and design stylist, Sarah Dean. She carries an extensive line of Redken and Pureology haircare products.  With her extensive knowledge in Redken and Pureology haircare she can provide you with a perfectly personalized  regimen."
                }
                contact={false}
              />

              <div className="events-promo-card">
                <div className="events-promo-card-header">
                  <h4>
                    <span>Hair Loss Restoration</span>
                    <br />
                    <span style={{ fontSize: "15px" }}>
                      Where science, technology & results meet.
                    </span>
                  </h4>
                  <p>
                    Hair loss restoration services at Prime are provided by Hair
                    Loss Restoration Co.
                  </p>
                  <h6>OUR VISION</h6>
                  <p>
                    To be an information source and provide services for clients
                    experiencing hair loss, helping them obtain the best
                    decision regarding their goals and expectations for hair
                    health and regrowth.
                  </p>
                  <h6>SERVICES</h6>
                  <ol>
                    <li>Initial comprehensive analysis.</li>
                    <li>
                      Hair wear for those who want an instant solution for
                      thinning hair.
                    </li>
                    <li>Laser hair therapy.</li>
                    <li>
                      The best products on the market for your hair loss needs;
                      compounding prescriptions available.
                    </li>
                    <li>Plasma rich platelet (PRP) therapy.</li>
                    <li>
                      On-Site immunologist, dermatologist, allergist, IV
                      nutrition therapy.
                    </li>
                    <li>Follow-up analysis and scope.</li>
                  </ol>
                  <div className="events-promo-card-contact">
                    <p>
                      For appointments and pricing, contact Kellie August phone-
                      918-605-5377
                    </p>

                    <div className="promoitemlink">
                      <a
                        href="https://www.hairlossrestorationco.com"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        www.hairlossrestorationco.com
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <div className="events-promo-card">
                <div className="events-promo-card-header">
                  <h4>
                    <span>Permanent Cosmetics</span>
                  </h4>

                  <p>
                    Permanent Cosmetics can enhance your brows, eyes and lips
                    with results that last!  Save time on your daily beauty
                    routine and look your best morning, noon and night.  It is
                    especially beneficial for people who can’t wear cosmetics
                    due to allergies and sensitive skin, active people who don’t
                    want to worry about sweating off and reapplying cosmetics,
                    and those who are visually impaired and have difficulty
                    applying cosmetics. 
                  </p>
                  <p>
                    3D Aereola Pigmentation: *COMING SOON* Women who have
                    undergone mastectomies, other breast surgery or are simply
                    not happy with their areola may elect to have permanent
                    re-pigmentation of the breast. Techniques such as permanent
                    areola re-pigmentation and nipple restoration employs
                    cosmetically tattooed micro pigmentation as a way to restore
                    the natural beauty of your breasts.
                  </p>
                  <p>
                    Schedule a complimentary consultation for pricing with
                    either Karen Barnett or Tammy Mathias.
                  </p>
                  <p>
                    Karen Barnett, RDH, CMM Microblading & Permanent Makeup
                    Artist <br />
                    Cell: 918-230-8862 <br />
                    Facebook link: /skindeepabrowstul <br />
                    Instagram link: /skindeepabrowstul
                    <div className="promoitemlink">
                      <a
                        href="https://skindeepbrows.com"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        www.skindeepbrows.com
                      </a>
                    </div>
                  </p>
                  <p>
                    Tammy Mathias, RDH, CMM Permanent Cosmetic Artist Cell:
                    918-606-3664
                  </p>
                </div>
              </div>
              <EventsPromoItem name={"Marissa – New lash tech/esthetician"} />
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }
}

export default EventsPromotion;
